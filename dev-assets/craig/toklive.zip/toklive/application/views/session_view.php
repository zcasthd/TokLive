<?php
  echo json_encode($session);
?>