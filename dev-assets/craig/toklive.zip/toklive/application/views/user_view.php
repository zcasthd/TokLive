<?php
  $status = array();
  $status["status"] = "ok";
  echo json_encode($status);
?>